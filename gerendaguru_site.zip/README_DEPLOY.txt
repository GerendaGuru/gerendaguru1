Gerenda Guru Kft. - weboldal csomag
----------------------------------
Fájlok:
- index.html
- styles.css
- script.js (ha van)
- logo.png, flyer.png (munkafotók és logó)

Gyors telepítési útmutató:
1) cPanel / FTP:
   - Lépj be a tárhelyed vezérlőpultjába.
   - Töltsd fel a zip-et vagy bontsd ki a fájlokat a public_html (vagy kiválasztott) mappába.
   - Állítsd be a domain DNS-ét a tárhelyre mutatva.
2) GitHub Pages:
   - Hozz létre egy repo-t, töltsd fel a fájlokat, és állítsd be a Pages forrást a 'main' branch / root mappára.
3) Netlify / Vercel:
   - Húzd rá a ZIP-et vagy repo-t, állítsd be build nélkül (static), és deploy-old.

Fontos:
- Módosítsd az index.html-ben az e-mail címet, telefonszámot és egyéb helykitöltőket.
- Ha szeretnéd, segítek feltölteni és beállítani a domaint (küldd a tárhely szolgáltatód adatait vagy repo linket).